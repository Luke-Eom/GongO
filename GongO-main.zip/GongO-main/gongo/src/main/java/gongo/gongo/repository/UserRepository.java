// package gongo.gongo.repository;

// import org.springframework.data.jpa.repository.JpaRepository;

// import gongo.gongo.entity.User;
 
 
// public interface UserRepository extends JpaRepository<User, String> {
// 	User findOneById(String id);
// }
