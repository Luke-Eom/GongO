// package gongo.gongo.entity;

// import java.util.Set;

// import javax.persistence.Column;
// import javax.persistence.Entity;
// import javax.persistence.GeneratedValue;
// import javax.persistence.GenerationType;
// import javax.persistence.Id;
// import javax.persistence.ManyToMany;
// import javax.persistence.Table;

// import lombok.AccessLevel;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
 
// @NoArgsConstructor(access = AccessLevel.PROTECTED)
// @Getter
// @Entity
// @Table(name = "tb_role")
// public class Role {
 
// 	@Id
// 	@GeneratedValue(strategy= GenerationType.IDENTITY)
// 	@Column(name = "id")
// 	private Long id;
 
// 	@Column(name = "name")
// 	private String name;
 
// 	@ManyToMany(mappedBy = "roles")
// 	private Set<User> users;
// }