package gongo.gongo.enums;

public enum UserRoles {
    SYSTEM, BOARD, USER
}
