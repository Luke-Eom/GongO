package gongo.gongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GongoApplication.class, args);
	}

}
