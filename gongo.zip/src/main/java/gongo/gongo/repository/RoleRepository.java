// package gongo.gongo.repository;

// import org.springframework.data.jpa.repository.JpaRepository;

// import gongo.gongo.entity.Role;

 
// public interface RoleRepository extends JpaRepository<Role, Long> {
// 	Role findOneById(Long id);
// }
